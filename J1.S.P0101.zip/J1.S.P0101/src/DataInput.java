
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class DataInput {

    public int checkIntputLimit(int min, int max) {
        Scanner sc = new Scanner(System.in);
        //repeat until correct input
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine());
                //if within min max then return result
                if (result >= min && result <= max) {
                    return result;
                } else {
                    System.out.println("Please enter " + min + " to " + max);
                    System.out.println("Enter again:");
                }
            } catch (Exception e) {
                System.out.println("Please enter " + min + " to " + max);
                System.out.println("Enter again:");
            }
        }
    }

    public String inputID(List<Employee> employee) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("ID: ");
        while (true) {
            String id = scanner.nextLine().trim();
            id = id.replace("\\s+", "");
            if (!id.isEmpty()) { //nếu chuỗi ko rỗng 
                if (!isDuplicatedID(id, employee)) { //ko tồn tại bản ghi 
                    return id;//trả về id mới được nhập vào
                } else {
                    System.out.print("ID is already in use "
                            + " please enter another ID: ");
                }
            } else { 
                System.out.print("ID can not empty, enter again: ");
            }
        }
    }

    private boolean isDuplicatedID(String id, List<Employee> employee) {
        for (Employee em : employee) {
            if (em.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }
//dungf cho phần update bên view
    public String inputExistedID(List<Employee> employee) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Employee ID: ");
        //vòng lặp cho đến khi có lựa chọn hợp lệ được nhập
        while (true) {
            String id = scanner.nextLine().trim();
            if (!id.isEmpty()) {             
                if (isDuplicatedID(id, employee)) {//tồn tại bản ghi
                    return id;//trả về id của employee cần update
                } else {
                    System.out.print("ID not found, enter again: ");
                }
            } else { // empty string ~> display error & re-enter
                System.out.print("ID can not empty, enter again: ");
            }
        }
    }

    public String inputString(String name) {
        Scanner scanner = new Scanner(System.in);

        System.out.print(name + ": ");
        //vong lặp cho đến khi nhập String  hợp lệ
        while (true) {
            String string = scanner.nextLine().trim();
            if (!string.isEmpty()) { 
                return string.toUpperCase();
            } else { // empty string ~> display error & re-enter
                System.out.print(name + " can not empty, enter again: ");
            }
        }
    }

    public String inputName(String name) {
        Scanner scanner = new Scanner(System.in);

        System.out.print(name + ": ");
        // loop until have valid name were inputted
        while (true) {
            String string = scanner.nextLine().trim();
            if (!string.isEmpty()) { // not empty ~> check next condition
                if (isValidStringLetter(string)) {
                    return string.toUpperCase();
                } else {
                    System.out.print(name + " can not contain special "
                            + "characters or digits, enter again: ");
                }
            } else { // empty string ~> display error & re-enter
                System.out.print(name + " can not empty, enter again: ");
            }
        }
    }
    //ktra chuoõi ký tự hợp lệ
    private boolean isValidStringLetter(String name) {
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);  //tách từng ký tự
            if (!Character.isLetter(c) && c != ' ') {//neu mà có ký tự đặc biệt (ngoài khoảng trằng )thì trả về false
                return false;
            }
        }
        return true;
    }


    public String inputPhone() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Phone number: ");
        // loop until have valid phone number were inputted
        while (true) {
            String raw = scanner.nextLine().trim();
            if (!raw.isEmpty()) { // not empty ~> check next condition
                if (checkPhone(raw)) {
                    return raw;
                }
            } else { // empty string ~> display error & re-enter
                System.out.print("Phone number can not empty, enter again: ");
            }
        }
    }
    public Scanner sc = new Scanner(System.in);
    public String inputPhone1() {
        while (true) {
            System.out.print("Input number (ex: 0582327428): ");
            String phoneNumber = sc.nextLine().trim();
            if (phoneNumber.matches("[0-9]{10}")) {
                return phoneNumber;
            }
            System.out.println("Phone is number.Please input again.");
        }
    }

    private boolean checkPhone(String stringPhone) {
        String s = stringPhone.substring(1);
        if (stringPhone.charAt(0) == '0') {
            if (s.isEmpty()) {
                System.out.print("Phone number can not empty, enter again: ");
                return false;
            }
            if (s.matches("^[0-9]{9,20}$")) {
                return true;
            } else {
                System.out.print("Phone must a string of numbers and has 10-20 digits, enter again: ");
                return false;
            }
        } else {
            System.out.print("Phone number must start by '0', enter again: ");
            return false;
        }
    }

    public String inputEmail() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Email: ");
        // loop until have valid name were inputted
        while (true) {
            String s = scanner.nextLine().trim();
            s = s.replace("\\s+", " ");
            if (!s.isEmpty()) { // not empty ~> finish
                if (s.matches("^[a-z0-9A-Z]+@[a-zA-Z]+(\\.[a-zA-Z]+){1,3}+$")) {
                    return s;
                } else {
                    System.out.print("Email must in format "
                            + "Local-Part(name(.name2)@Domain(domain.something(.domain2.domain3))(max 3 '.'), enter again: ");
                }
            } else { // empty string ~> display error & re-enter
                System.out.print("Email can not empty, enter again: ");
            }
        }
    }

 

    public Date inputDate() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Date of birth: ");
        // loop until have valid name were inputted
        while (true) {
            String raw = scanner.nextLine().trim();
            if (!raw.isEmpty()) { 
              
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                try {
                    //chuyển đổi string thành date.(nhặt ra chuỗi hợp lê)
                    //ex: nam24/06/2001 => Sun Jun 24 00:00:00 ICT 2001  
                    Date date = sdf.parse(raw);  // 31/2/2001 =>3/3/2001
                    // chuyển đổi date thành string
                    String result_str = sdf.format(date);
                    //so sanh chuỗi sau khi được chuẩn hóa với chuỗi được nhập vào ban đầu
                    if (result_str.equals(raw)) {//ko có sự thay đổi => chuỗi đầu vào đã đạt chuẩn
                        return date;
                    } else {
                        System.out.print("Please enter a right date, enter again: ");
                    }
                } catch (ParseException e) {
                    System.out.print("Date of birth must in format dd/MM/yyyy, enter again: ");
                }
            } else { //Empty
                System.out.print("Date of birth can not empty, enter again: ");
            }
        }
    }

    public boolean checkAge(Date day) {
        Calendar now = Calendar.getInstance();
        Calendar dob = Calendar.getInstance();
        dob.setTime(day);//thiết lập time của dob với day
        if (dob.after(now)) {
            System.out.println("Can't be born in the future");
            return false;
        }
        int year1 = now.get(Calendar.YEAR);
        int year2 = dob.get(Calendar.YEAR);
        int age = year1 - year2;
        int month1 = now.get(Calendar.MONTH);
        int month2 = dob.get(Calendar.MONTH);
        if (month2 > month1) {//nếu tháng DoB > tháng hiện tại thì chưa đủ 18 tuổi
            age--;
        } else if (month1 == month2) {
            int day1 = now.get(Calendar.DAY_OF_MONTH);
            int day2 = dob.get(Calendar.DAY_OF_MONTH);
            if (day2 > day1) {//nếu cùng tháng nma ngày của DoB > ngày hiện tại thì sẽ chưa đủ 18 tuổi
                age--;
            }
        }
        if (age >= 18) {
            return true;
        } else {
            System.out.println("You are under 18 years old.");
            return false;
        }
    }

    public String inputSex() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Sex: ");
        // loop until have valid sex were inputted
        while (true) {
            String s = scanner.nextLine();
            s = s.replaceAll("\\s+", "");
            if (!s.isEmpty()) {
                    if (s.toLowerCase().equals("male")
                            || s.toLowerCase().equals("female")) {
                        return s.toUpperCase();
                    } else {
                        System.out.print("Gender must be male or female, enter again: ");
                    }
            } else {
                System.out.print("Gender can not empty, enter again: ");
            }
        }
    }

    public double inputSalary() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Salary: ");
        while (true) {
            String raw = scanner.nextLine().trim();
            if (!raw.isEmpty()) { // not empty 
                try {
                    double price = Double.parseDouble(raw);
                    if (price > 0) {
                        return price;
                    } else {
                        System.out.print("Salary must more than 0, enter again: ");
                    }
                } catch (NumberFormatException e) {
                    System.out.print("Salary must be a numberical value, enter again: ");
                }
            } else { // empty string 
                System.out.print("Salary can not empty, enter again: ");
            }
        }
    }
  public  boolean checkYesNo(String notification) {
        //loop until user input correct
        while (true) {
            String result = inputString(notification);
            //return true if user input y/Y
            if (result.equalsIgnoreCase("Y")) {
                return true;
            }
            //return false if user input n/N
            if (result.equalsIgnoreCase("N")) {
                return false;
            }
            System.err.println("Please input y/Y or n/N.");
            System.out.print("Enter again: ");
        }
    }
//    public boolean checkYesNo(String notification) {
//        Scanner in = new Scanner(System.in);
//        System.out.println(notification);
//        System.out.print("Enter your choice: ");
//        while (true) {
//            String s = in.nextLine();
//            if (!s.isEmpty()) {
//                s = s.replaceAll(" ", "");
//                if (s.compareToIgnoreCase("Y") == 0 || s.compareToIgnoreCase("y") == 0) {
//                    return true;
//                }
//                if (s.compareToIgnoreCase("N") == 0 || s.compareToIgnoreCase("n") == 0) {
//                    return false;
//                }
//                System.out.print("You must choose Yes(Y) or No(N)!\nEnter again: ");
//            } else {
//                System.out.print("Choice can not empty, enter again: ");
//            }
//        }
//    }

}
