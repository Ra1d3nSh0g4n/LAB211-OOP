
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmployeeManager {

    private List<Employee> employees = new ArrayList<>();

    public List<Employee> getEmployee() {
        return employees;
    }
    //them Employee 
    public void addEmployee(Employee e) {
        employees.add(e);
    }
    //trả về Employee bằng tìm kiếm qua ID
    public Employee getEmployeeByID(String id) {
        for (Employee e : employees) {
            if (id.equals(e.getId())) {
                return e;
            }
        }
        return null;
    }
    //HÀM update 
    public void updateEmployee(Employee e) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getId() == e.getId()) {//tìm kiếm Employee có cùng ID 
                employees.set(i, e);                    //Set Employee mới cập nhật vào vị trí của Employee update
                break;
            }
        }
    }
    //xóa Employee
    public void removeEmployee(String id) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getId().equalsIgnoreCase(id)) {
                employees.remove(i);
            }
        }
    }
    //Nối  FirstName+LastName
    private String plusString(String firstName, String lastName) {
        String str;
        str = firstName + " " + lastName;
        return str;
    }
    //tìm kiếm Empoyee theo tên 
    public List<Employee> searchByName(List<Employee> employee, String searchValue) {
        List<Employee> searched = new ArrayList<>();//tạo ra 1 list để lưu các phần tử tìm dc 
        for (Employee e : employee) {
            if (plusString(e.getFirstName(), e.getLastName()).toLowerCase().contains(searchValue.toLowerCase())) //so khớp 
            {
                searched.add(e);
            }
        }
        return searched;
    }
    //sắp xếp theo Salary
    public void sortBySalary() {
        Collections.sort(employees, new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return (int ) (o1.getSalary()-o2.getSalary());
            }
        }
        );
    }
}
