
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args)  {
        DataInput in = new DataInput();
        View v = new View();

        while (true) {
            System.out.println("=======MAIN MENU=======");
            System.out.println("1. Add employees");
            System.out.println("2. Update employees");
            System.out.println("3. Remove employees");
            System.out.println("4. Search employees");
            System.out.println("5. Sort employees by salary");
            System.out.println("6. Exit");
            System.out.print("Your choice: ");
            int choice = in.checkIntputLimit(1, 6);
            switch (choice) {
                case 1: {
                    v.addEmployee();
                    break;
                }
                case 2: {
                    v.updateEmployee();
                    break;
                }
                case 3: {
                    v.removeEmployee();
                    break;
                }
                case 4: {
                    v.searchEmployee();
                    break;
                }
                case 5: {
                    v.sortBySalary();
                    break;
                }
                case 6: {
                    return;
                }
            }
        }

    }

}
