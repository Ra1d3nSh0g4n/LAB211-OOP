
import java.util.ArrayList;


public class Main {
    public static void main(String[] args) {      
        Validation val = new Validation();
        ArrayList<Student> list = new ArrayList<>();
        Controller c = new Controller(list);
        View v = new View(c);
        try {
            list.add(new Student("HE150767", "Phan Tuan Viet", "1", "Java"));
            list.add(new Student("HE150400", "Phan Tuan Viet", "2", "C/C++"));
            list.add(new Student("HE150401", "Pham Minh Duc", "2", "Java"));
            list.add(new Student("HE150767", "Phan Tuan Viet", "3", ".Net"));
            list.add(new Student("HE150771", "Nguyen Phuong Nam", "3", ".Net"));
            list.add(new Student("HE150771", "Nguyen Phuong Nam", "4", ".Net"));
            list.add(new Student("HE150767", "Phan Tuan Viet", "4", "C/C++"));
            list.add(new Student("HE150771", "Nguyen Phuong Nam", "4", "C/C++"));
            list.add(new Student("HE150771", "Nguyen Phuong Nam", "4", "Java"));
            list.add(new Student("HE150401", "Pham Minh Duc","4", "C/C++"));
        } catch (Exception e) {
        }
        
        int option;
        do {
            System.out.println("---------------------------");
            System.out.println("1.Add:");
            System.out.println("2.Find by name and Sort:");
            System.out.println("3.Update/Delete :");
            System.out.println("4.Report :");
            System.out.println("0.Exit Program:");
            System.out.println("----------------------------");
            System.out.print("Select a option:");
            option = val.Check_int();
            switch(option)
            {
                case 1:
                    v.Add_Student();break;
                case 2:
                    v.Find_By_Name();break;
                case 3:                         
                    v.Update_Or_Delete();break;                                                                                                                               
                case 4:
                    v.Report();break;
                case 0:
                    System.exit(0);
                default:
                    System.err.println("This function is not available,Re_select!!!");                    
            }
        } while (true);
        
    }
}

