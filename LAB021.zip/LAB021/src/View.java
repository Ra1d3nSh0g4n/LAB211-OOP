
import java.util.Scanner;


public class View {

    Validation val = new Validation();
    Controller cm ;

    public View(Controller cm) {
        this.cm = cm;
    }
    
    Scanner sc = new Scanner(System.in);
    
    //add
    public void Add_Student() {
        String ans_continue = "";
        
        while (!ans_continue.equalsIgnoreCase("N")) {
            Student s = new Student();

            System.out.print("Enter ID: ");
            s.setID(val.Input_String());

            if (cm.Existance_ID(s.getID()) != -1) {
                System.out.println("Enter name: " + cm.obj(s.getID()).getName());
                s.setName(cm.obj(s.getID()).getName());
                System.out.print("Enter Semester: ");
                s.setSemester(val.Input_String());
                System.out.print("Enter Course: ");              
                while(true){
                    s.setCourse_name(val.Input_Course());
                    if(!cm.Existance_Semester(s.getID(), s.getSemester(), s.getCourse_name()))
                        break;
                    else
                        System.err.print("The subject already exists this semester,Re-enter: ");
                }
                cm.Add(s);
            } else {
                System.out.print("Enter Name: ");
                s.setName(val.Input_String());
                System.out.print("Enter Semester: ");
                s.setSemester(val.Input_String());
                System.out.print("Enter Course: ");
                s.setCourse_name(val.Input_Course());

                cm.Add(s);
            }
            System.out.print("Do you want add continue( Y_Yes or N_No): ");
            ans_continue = val.Ans_Add();
            System.out.println("");
        }
    }

    //find and sort
    //tìm SV theo tên 
    public void Find_By_Name() {
        
        if (cm.List_Student().isEmpty()) {
            System.out.println("List is empty!!!");
        } else {
            String name;
            System.out.print("Enter name need find: ");
            name = sc.nextLine();
            
            System.out.println("-------------Search Result-------------");
            System.out.printf("%-8s  %-20s  %-10s  %-10s\n",
                "ID", "Name", "Semester", "Course"); 
            for (Student List1 : cm.Find_Sort(name)) {
                System.out.printf("%-8s  %-20s  %-10s  %-10s\n"
                ,List1.getID(),List1.getName(),List1.getSemester(),List1.getCourse_name());
            }
            
        }
    }

    //update/delete
    public void Update_Or_Delete() {
        if (cm.List_Student().isEmpty()) {
            System.out.println("List is empty!!!");
        } else {
            String ID = "";
            System.out.print("Enter ID of Student you want find: ");
            while (cm.Existance_ID(ID) == -1) {
                ID = val.Input_String();
                if (cm.Existance_ID(ID) == -1) {
                    System.err.println("ID is not exist,Re-enter:");
                }
            }
            System.out.println("");
            System.out.printf("%-3s  %-6s  %-15s  %-10s  %-10s\n","STT",
                "ID", "Name", "Semester", "Course");
            for (int i = 0; i < cm.List_By_ID(ID).size(); i++) {
                System.out.printf("%-3s  %-6s  %-15s  %-10s  %-10s\n",i,
                    cm.List_By_ID(ID).get(i).getID(),cm.List_By_ID(ID).get(i).getName(),
                    cm.List_By_ID(ID).get(i).getSemester(),cm.List_By_ID(ID).get(i).getCourse_name());
                }
            int select;
            System.out.print("Select an element you want to edit(0->" + (cm.List_By_ID(ID).size() - 1 ) + "): ");
            while(true){    //check input select(only enter digit and less than cm.List_By_ID(ID).size() - 1
                select = val.Check_int();
                if(select <= cm.List_By_ID(ID).size() - 1)
                    break;
                else
                    System.err.println("Re-enter(0->"+ (cm.List_By_ID(ID).size() - 1 ) + "): ");
            }
            int Index = cm.obj(select, ID);    //return a obj in List_By_ID(ID)

            String ans;
            System.out.print("update or delete(U/D):");
            ans = val.Ans_UpOrDe();
            if(ans.equalsIgnoreCase("D")) {   //delete an obj selected object above          
                cm.List_Student().remove(Index); 
                System.out.println("Delete successfull...");
            }
            else{   //choose update               
                System.out.print("Enter new Semester: ");
                String Semester_temp = val.Input_String();
                cm.List_Student().get(Index).setSemester(Semester_temp);
                System.out.print("Enter new Course: ");
                while(true){
                    String Course_temp = val.Input_Course();
                    if(!cm.Existance_Semester(cm.List_Student().get(Index).getID(), 
                            cm.List_Student().get(Index).getSemester(), Course_temp)) {
                        cm.List_Student().get(Index).setCourse_name(Course_temp);
                        break;
                    }
                    else
                        System.err.print("The subject already exists this semester,Re-enter: ");
                    
                }
            }
        }     
    }

    //Report
    public void Report() {
        if (cm.List_Student().isEmpty()) {
            System.out.println("List is empty!!!");
        } else {
            System.out.printf("%-8s  %-20s  %-10s  %-5s\n",
                "ID", "Name", "Course", "Total");
            for (int i = 0; i < cm.Report().size(); i++) {
                System.out.printf("%-8s  %-20s  %-10s  %-5s\n",cm.Report().get(i).getId()
                ,cm.Report().get(i).getStudentName(),cm.Report().get(i).getCourseName(),cm.Report().get(i).getTotalCourse());
            }
        }
    }
}
