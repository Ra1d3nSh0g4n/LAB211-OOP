
public class H202 {
    public static void printReverse(String s){
        if(s.isEmpty()){
            return;
        }
        for(int i=s.length()-1;i>=0;i--){
            System.out.print(s.charAt(i));
        }
        System.out.println();
    }
    public static void main(String[] args) { 
        printReverse("hello there!");
}
}
