
import java.util.Scanner;

public class H203 {
    public static void  printReverse(String s){
        Scanner sc = new Scanner(System.in);
        while(s.trim().isEmpty()){
            System.out.println("Input again");
            s = sc.nextLine();
        }
        String[] a = s.split("\\.");
        String b = "";
        String d = "";
        int count = 0;
        int coun1 = 0;
        for(int i=a.length-1;i>=0;i--){
            if(count==1){
                b +=". ";
            }
            String[] c = a[i].split("\\s");
            for(int j=c.length-1;j>=0;j--){
                if(coun1%2==0){
                    d += c[j].substring(0, 1).toUpperCase() + c[j].substring(1)+" ";
                }
                else{
                    d += c[j] + " "; 
                    }
                coun1++;   
            }
            b += a[i]+"";
            count++;
        }
        
        
        System.out.print(d);
    }
    
    public static void main(String[] args) {
        printReverse("hello there. abc xyz");
       // Xyz abc. There hello
    } 
}
