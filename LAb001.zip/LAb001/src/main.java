
import java.util.Random;
import java.util.Scanner;

public class main {
    private static final Scanner in = new Scanner(System.in);
    private static int checkInput(){//check gia tri dau vao xem co hop le ko
        while(true){
            try{
                int result = Integer.parseInt(in.nextLine().trim());
                return result;  
            }catch(NumberFormatException e){
                System.err.println("Please input positive decimal number:");
                System.out.println("Enter again: ");
                }
        }
    }
    private static int inputSizeOfArray(){ //input so  phan tu cua array
        System.out.println("Enter number of array: ");
        int n = checkInput();
        return n;
    }
    private static int[] inputValueOfArray(int n){// nhay random cac so tu 1 den n(n la size arr)
        Random rand = new Random();
        int[] a = new int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = rand.nextInt(n)+1;
        }
        return a;
    }
    private static void sortArrayByBubbleSort(int[] a){//sort cac phan tu sau khi nhay random
        int temp;
        for(int i=0;i<a.length;i++){
            for(int j=0; j<a.length-i-1;j++){
                if(a[j]>a[j+1]){
                    temp = a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
    }
    private static void print(int[] a){//hien arr
        for(int i = 0;i<a.length;i++){
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        int n = inputSizeOfArray();
        int[] a = inputValueOfArray(n);
        System.out.println("Unsorted array: ");
        print(a);
        sortArrayByBubbleSort(a);
        System.out.println("Sorted array: ");
        print(a);
    }
    
}
