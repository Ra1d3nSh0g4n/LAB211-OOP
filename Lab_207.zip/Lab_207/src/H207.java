
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class H207 {
    public static int secondHalfLetters(String name){
        int count =0;
        Pattern p = Pattern.compile("[n-zN-Z]");
        Matcher m = p.matcher(name);
        for(int i=0;i<name.length();i++){
            if(m.find())
                count++;
        }
        return count;
    }
    public static void main(String[] args) {
         System.out.println(secondHalfLetters("nrabcefn")); 
    }
}
